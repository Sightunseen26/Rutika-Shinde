import sqlite3
import os
import re
def createdb():
    # Ensure the resources directory exists
    if not os.path.exists('resources'):
        os.makedirs('resources')

    db_path = 'resources/normanpd.db'
    os.remove(db_path) if os.path.exists(db_path) else None
    # Connect to the database file or create it if it doesn't exist
    db = sqlite3.connect(db_path)
    cursor = db.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS incidents (
            incident_time TEXT,
            incident_number TEXT,
            incident_location TEXT,
            nature TEXT,
            incident_ori TEXT
        )
    ''')
    db.commit()
    return db

def populatedb(db, incidents):
    cursor = db.cursor()
    for incident in incidents:
        cursor.execute('''
            INSERT INTO incidents VALUES (?, ?, ?, ?, ?)
        ''', incident)
    db.commit()

def status(db):
    cursor = db.cursor()
    cursor.execute('''
        SELECT nature, COUNT(*) as count
        FROM incidents
        GROUP BY nature
        ORDER BY count DESC, nature
    ''')
    pattern = r'^RAMP'
    for row in cursor.fetchall():
        if(re.match(pattern,row[0])):
            continue
        else:
            print(f'{row[0]}|{row[1]}')
