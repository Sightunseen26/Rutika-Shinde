import re
import pypdf as PyPDF2

def extractincidents(incident_data):
    with open(incident_data, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(incident_data)
        text = ""
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text(extraction_mode="layout")

    lines = text.splitlines()
    lines = lines[3:]
    lines = lines[:-1]

    data = []
   
    for l in lines:
        if l != "":
            date_pattern = r'\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}'
            matches = re.finditer(date_pattern, l)
            if matches:
                indices = [match.start() for match in matches]
                matched_lines = [l[i:j].strip() for i, j in zip([0] + indices, indices + [None])]
                matched_lines = list(filter(None, matched_lines))
                for ml in matched_lines:
                    split_line = re.split("   ", ml)
                    non_empty_list = [value for value in split_line if value is not None and value != ""]

                    if len(non_empty_list) == 5:
                        date_time = non_empty_list[0].strip()
                        incident_number = non_empty_list[1].strip()
                        location = non_empty_list[2].strip()
                        nature = non_empty_list[3].strip() if non_empty_list[3] != " " else non_empty_list[3]
                        incident_type = non_empty_list[4].strip()

                        extracted_data = (date_time, incident_number, location, nature, incident_type)

                        # Append the data to the list
                        data.append(extracted_data)

                    else:
                        nature = ""
                        for entry in non_empty_list:
                            if entry.isalpha():
                                nature = entry

                        extracted_data = ("", "", "", nature, "")

                        data.append(extracted_data)

            else:
                matched_lines = [l.strip()]
                split_line = re.split("   ", l)

                non_empty_list = [value for value in split_line if value is not None and value != ""]

                if len(non_empty_list) == 5:
                    date_time = non_empty_list[0].strip()
                    incident_number = non_empty_list[1].strip()
                    location = non_empty_list[2].strip()
                    nature = non_empty_list[3].strip() if non_empty_list[3] != " " else non_empty_list[3]
                    incident_type = non_empty_list[4].strip()

                    extracted_data = (date_time, incident_number, location, nature, incident_type)

                    # Append the data to the list
                    data.append(extracted_data)

                else:
                    nature = ""
                    for entry in non_empty_list:
                        if entry.isalpha():
                            nature = entry

                    extracted_data = ("", "", "", nature, "")

                    data.append(extracted_data)
    return data
