import re

headers = {}
headers[
    "User-Agent"
] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
url2 = ("https://www.normanok.gov/sites/default/files/documents/2024-01/2024-01-01_daily_incident_summary.pdf")


def test_dummy():
    """Tests basics multiplication functionality. """
    print("ran")
    assert 3 * 2 == 6

# Sample text from the PDF
pdf_text = """
Date / Time Incident Number Location Nature Incident ORI
1/25/2024 0:00 2024-00005499 1446 TELLURIDE LN Check Area OK0140200
1/25/2024 0:01 2024-00005500 2338 W LINDSEY ST Traffic Stop OK0140200
1/25/2024 0:11 2024-00005501 3450 CHAUTAUQUA AVE Alarm OK0140200
1/25/2024 0:18 2024-00001408 1916 DELANCEY DR Abdominal Pains/Problems 14005
1/25/2024 0:18 2024-00001749 1916 DELANCEY DR Abdominal Pains/Problems EMSSTAT
1/25/2024 0:20 2024-00005502 2550 MOUNT WILLIAMS DR Larceny OK0140200
1/25/2024 0:28 2024-00005503 1325 W LINDSEY ST Suspicious OK0140200
# ... (remaining data)
"""

# Define regular expressions for each field
date_time_pattern = r'\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}'
incident_number_pattern = r'\d{4}-\d{8}'
location_pattern = r'.+'
nature_pattern = r'.+'
incident_ori_pattern = r'[A-Z]+\d+'

# Compile regular expressions
date_time_regex = re.compile(date_time_pattern)
incident_number_regex = re.compile(incident_number_pattern)
location_regex = re.compile(location_pattern)
nature_regex = re.compile(nature_pattern)
incident_ori_regex = re.compile(incident_ori_pattern)

# Extract fields from the text
matches = re.findall(rf'{date_time_pattern}\s+{incident_number_pattern}\s+{location_pattern}\s+{nature_pattern}\s+{incident_ori_pattern}', pdf_text)

# Process the matches
for match in matches:
    date_time = date_time_regex.search(match).group()
    incident_number = incident_number_regex.search(match).group()
    location = location_regex.search(match).group()
    nature = nature_regex.search(match).group()
    incident_ori = incident_ori_regex.search(match).group()

    # Print or process the extracted fields
    print(f"Date/Time: {date_time}, Incident Number: {incident_number}, Location: {location}, Nature: {nature}, Incident ORI: {incident_ori}")
