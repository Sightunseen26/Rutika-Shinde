headers = {}
headers[
    "User-Agent"
] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
url2 = ("https://www.normanok.gov/sites/default/files/documents/2024-01/2024-01-01_daily_incident_summary.pdf")



def test_dummy():
    """Tests basics multiplication functionality. """
    print("ran")
    assert 3 * 2 == 6

