
## Installation

1. Clone the repository
2. Install dependencies using `pipenv install`

## Running the Code

Use the following command to run the code:

```bash
pipenv run python assignment0/main.py --incidents <url>
